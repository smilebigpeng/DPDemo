//
//  SUTableViewInterceptor.h
//  ZHIBO
//
//  Created by 崔大鹏 on 16/12/1.
//  Copyright © 2016年 Hemaapp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SUTableViewInterceptor : NSObject

@property (nonatomic, weak) id receiver;
@property (nonatomic, weak) id middleMan;

@end
