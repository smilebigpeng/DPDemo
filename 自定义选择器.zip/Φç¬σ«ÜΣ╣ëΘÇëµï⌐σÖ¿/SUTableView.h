//
//  SUTableView.h
//  ZHIBO
//
//  Created by 崔大鹏 on 16/12/1.
//  Copyright © 2016年 Hemaapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SUTableView : UITableView

@end
